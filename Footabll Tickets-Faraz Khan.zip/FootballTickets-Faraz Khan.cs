﻿using System;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare variables

            const double taxValue = .085;
            int val1 = 0;
            double val2 = 0;

            //Calculations

            Console.WriteLine("FARAZ KHAN-MIS 3013-002");
        
            Console.WriteLine("What is the product name of the item you are purchasing?");
            Console.ReadLine();

            Console.WriteLine("How many football tickets do you want to buy?");
            val1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("What is the Price for each football ticket?");
            val2 = Convert.ToDouble(Console.ReadLine());

            double sub = Math.Round(val1 * val2, 2);

            Console.WriteLine("Your subtotal for your bill is: $"+ sub.ToString("f2") +".");


            Console.WriteLine("Your sales tax for your bill is: $"+ ((val1 * val2) * taxValue).ToString("f2") + ".");


            Console.WriteLine("Your total for your bill is: $"+ ((((val1 * val2) + ((val1 * val2) * taxValue)).ToString("f2") +".")));

            Console.WriteLine("Press any key to continue...");

            Console.ReadKey();



        }
    }
}
